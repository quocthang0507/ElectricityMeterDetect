using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
[assembly: AssemblyVersion("4.4.0.4099")]
[assembly: AssemblyFileVersion("4.4.0.4099")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Emgu Corporation")]
[assembly: AssemblyProduct("Emgu.CV")]
[assembly: AssemblyCopyright("Copyright Emgu Corporation 2020")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
