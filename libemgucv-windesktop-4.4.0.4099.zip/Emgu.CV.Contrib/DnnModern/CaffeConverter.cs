//----------------------------------------------------------------------------
//  Copyright (C) 2004-2020 by EMGU Corporation. All rights reserved.       
//----------------------------------------------------------------------------

/*
using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;
using Emgu.CV.Structure;
using Emgu.CV.Util;
using Emgu.Util;
using System.Diagnostics;

namespace Emgu.CV.Dnn2
{
   internal static partial class Dnn2Invoke
   {
      static Dnn2Invoke()
      {
         CvInvoke.CheckLibraryLoaded();
      }


      [DllImport(CvInvoke.ExternLibrary, CallingConvention = CvInvoke.CvCallingConvention)]
      internal static extern void cveCaffeConverterCreate(IntPtr modelFile, IntPtr trainedFile, IntPtr meanFile);

   }
}
*/