using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
[assembly: AssemblyVersion("2.4.10.1940")]
[assembly: AssemblyFileVersion("2.4.10.1940")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Emgu")]
[assembly: AssemblyProduct("Emgu.CV")]
[assembly: AssemblyCopyright("Copyright Emgu 2014")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
