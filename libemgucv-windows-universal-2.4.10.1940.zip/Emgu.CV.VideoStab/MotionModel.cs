﻿//----------------------------------------------------------------------------
//  Copyright (C) 2004-2013 by EMGU. All rights reserved.       
//----------------------------------------------------------------------------

using System;
using System.Collections.Generic;

namespace Emgu.CV.VideoStab
{
   /*
   public enum MotionModel
   {
      TRANSLATION = 0,
      TRANSLATION_AND_SCALE = 1,
      LINEAR_SIMILARITY = 2,
      AFFINE = 3,
      HOMOGRAPHY = 4,
      UNKNOWN = 5
   }*/
}
